package com.qos.latency.analyzer.controller;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.qos.latency.analyzer.model.LatencyModel;
import com.qos.latency.analyzer.view.ChartView;

import java.util.List;

/**
 * Contrôleur pour l'animation des données request_array.
 *
 * Gère l'affichage chronologique progressif des paquets réseau.
 *
 * @author Équipe QoS Gaming
 * @version 3.0
 */
public class LatencyController {

    private static final String TAG = "LatencyController";

    private LatencyModel model;
    private ChartView chartView;
    private Handler animationHandler = new Handler(Looper.getMainLooper());
    private ControllerListener listener;

    private boolean isAnimating;
    private boolean isInVisualizationPause;
    private int currentPacketIndex = 0;
    private List<LatencyModel.RequestData> currentPacketList;

    private static final int PACKET_ANIMATION_DELAY = 100;

    /**
     * Interface de callbacks simplifiée.
     */
    public interface ControllerListener {
        void onAnimationStarted();
        void onAnimationFinished();
        void onAnalysisStarted(String analysisName);
        void onPacketDisplayed(LatencyModel.RequestData packet, int displayedCount, int totalCount);
        void onVisualizationPauseCountdown(int remainingSeconds);
        void onVisualizationPauseFinished();
    }

    public LatencyController(LatencyModel model, ChartView chartView, Context context) {
        if (model == null || chartView == null || context == null) {
            throw new IllegalArgumentException("Paramètres requis");
        }
        this.model = model;
        this.chartView = chartView;
    }

    public void setListener(ControllerListener listener) {
        this.listener = listener;
    }

    public boolean isAnimating() {
        return isAnimating || isInVisualizationPause;
    }

    public void cleanup() {
        stopAnimation();
        listener = null;
    }

    /**
     * Démarre l'animation des données request_array.
     */
    public void startAnimation() {
        try {
            if (isAnimating() || !model.hasData()) {
                return;
            }

            isAnimating = true;
            chartView.clearAllSeries();
            chartView.setTimestampMode(true);

            LatencyModel.RequestArrayData requestArrayData = model.getRequestArrayData();
            currentPacketList = requestArrayData.getRequestDataList();
            currentPacketIndex = 0;

            if (listener != null) {
                listener.onAnimationStarted();
                listener.onAnalysisStarted("Analyse chronologique - " + currentPacketList.size() + " paquets");
            }

            animateNextPacket();

        } catch (Exception e) {
            Log.e(TAG, "Erreur animation: " + e.getMessage());
            isAnimating = false;
        }
    }

    /**
     * Anime le paquet suivant.
     */
    private void animateNextPacket() {
        if (!isAnimating) return;

        try {
            if (currentPacketIndex < currentPacketList.size()) {
                LatencyModel.RequestData packet = currentPacketList.get(currentPacketIndex);

                if (packet != null) {
                    chartView.addPacketPoint(packet);

                    if (listener != null) {
                        listener.onPacketDisplayed(packet, currentPacketIndex + 1, currentPacketList.size());
                    }
                }

                currentPacketIndex++;
                animationHandler.postDelayed(this::animateNextPacket, PACKET_ANIMATION_DELAY);

            } else {
                startVisualizationPause();
            }

        } catch (Exception e) {
            Log.e(TAG, "Erreur paquet: " + e.getMessage());
            stopAnimation();
        }
    }

    public void stopAnimation() {
        isAnimating = false;
        isInVisualizationPause = false;
        animationHandler.removeCallbacksAndMessages(null);

        if (listener != null) {
            listener.onAnimationFinished();
        }
    }

    /**
     * Démarre la pause de visualisation.
     */
    private void startVisualizationPause() {
        isAnimating = false;
        isInVisualizationPause = true;

        if (listener != null) {
            listener.onAnimationFinished();
        }

        startCountdown(30);
    }

    private void startCountdown(int remainingSeconds) {
        if (!isInVisualizationPause) return;

        if (remainingSeconds > 0) {
            if (listener != null) {
                listener.onVisualizationPauseCountdown(remainingSeconds);
            }
            animationHandler.postDelayed(() -> startCountdown(remainingSeconds - 1), 1000);
        } else {
            isInVisualizationPause = false;
            if (listener != null) {
                listener.onVisualizationPauseFinished();
            }
        }
    }
}