package com.qos.latency.analyzer.model;

import android.content.Context;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Modèle de données pour l'analyse de latence au format request_array.
 *
 * Charge et structure les données de paquets avec timestamps pour l'affichage chronologique.
 *
 * @author Équipe QoS Gaming
 * @version 3.0
 */
public class LatencyModel {

    private RequestArrayData requestArrayData;
    private String currentFileName = "";

    public LatencyModel() {
        requestArrayData = new RequestArrayData();
    }

    /**
     * Statuts possibles pour un paquet réseau.
     */
    public enum PacketStatus {
        RECEIVED, LOST, DUPLICATED, REVERSED
    }

    /**
     * Données d'un paquet réseau individuel.
     */
    public static class RequestData {
        private long txTimestamp;
        private long rxTimestamp;
        private double rtt;
        private PacketStatus status;
        private int sequenceNumber;
        private double txTimeRelative;
        private double rxTimeRelative;

        public RequestData(int sequenceNumber, long txTimestamp, long rxTimestamp,
                           double rtt, PacketStatus status) {
            this.sequenceNumber = sequenceNumber;
            this.txTimestamp = txTimestamp;
            this.rxTimestamp = rxTimestamp;
            this.rtt = rtt;
            this.status = status;
        }

        public void calculateRelativeTimes(long t0) {
            this.txTimeRelative = (txTimestamp - t0) / 1_000_000.0;
            if (status == PacketStatus.RECEIVED) {
                this.rxTimeRelative = (rxTimestamp - t0) / 1_000_000.0;
            } else {
                this.rxTimeRelative = this.txTimeRelative;
            }
        }

        // Getters essentiels
        public PacketStatus getStatus() { return status; }
        public int getSequenceNumber() { return sequenceNumber; }
        public double getTxTimeRelative() { return txTimeRelative; }
        public double getRxTimeRelative() { return rxTimeRelative; }
        public double getRtt() { return rtt; }
    }

    /**
     * Contient les données d'une mesure request_array.
     */
    public static class RequestArrayData {
        private List<RequestData> requestDataList = new ArrayList<>();
        private long baseTimestamp = 0;

        public void addRequestData(int sequenceNumber, long txTimestamp, long rxTimestamp,
                                   double rtt, boolean duplicated, boolean reversed) {

            PacketStatus status;
            if (rxTimestamp == 0) {
                status = PacketStatus.LOST;
            } else if (duplicated) {
                status = PacketStatus.DUPLICATED;
            } else if (reversed) {
                status = PacketStatus.REVERSED;
            } else {
                status = PacketStatus.RECEIVED;
            }

            if (baseTimestamp == 0) {
                baseTimestamp = txTimestamp;
            }

            RequestData request = new RequestData(sequenceNumber, txTimestamp, rxTimestamp, rtt, status);
            request.calculateRelativeTimes(baseTimestamp);
            requestDataList.add(request);
        }

        public void clear() {
            requestDataList.clear();
            baseTimestamp = 0;
        }

        public List<RequestData> getRequestDataList() { return requestDataList; }
        public boolean hasData() { return !requestDataList.isEmpty(); }
    }

    /**
     * Récupère la liste des fichiers JSON disponibles.
     */
    public static List<String> getAvailableDataFiles(Context context) {
        List<String> jsonFiles = new ArrayList<>();
        try {
            String[] allFiles = context.getAssets().list("");
            if (allFiles != null) {
                for (String fileName : allFiles) {
                    if (fileName.endsWith(".json")) {
                        jsonFiles.add(fileName);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonFiles;
    }

    public String getDisplayFileName() {
        if (currentFileName.isEmpty()) return "Aucun fichier";
        return currentFileName.replace(".json", "").replace("_", " ");
    }

    /**
     * Charge les données depuis un fichier JSON request_array.
     */
    public void loadData(Context context, String fileName) {
        try {
            if (!fileName.endsWith(".json")) {
                fileName += ".json";
            }

            InputStream inputStream = context.getAssets().open(fileName);
            Scanner scanner = new Scanner(inputStream, "UTF-8");
            String jsonString = scanner.useDelimiter("\\A").next();
            scanner.close();
            inputStream.close();

            this.currentFileName = fileName;
            JSONObject root = new JSONObject(jsonString);
            requestArrayData.clear();

            if (root.has("request_array")) {
                JSONObject requestArray = root.getJSONObject("request_array");

                for (int i = 0; i < requestArray.length(); i++) {
                    String key = String.valueOf(i);
                    if (requestArray.has(key)) {
                        JSONObject request = requestArray.getJSONObject(key);

                        long txTimestamp = request.getLong("tx_ts");
                        long rxTimestamp = request.optLong("rx_ts", 0);
                        double rtt = request.getDouble("rtt");
                        boolean duplicated = request.optInt("duplicated", 0) == 1;
                        boolean reversed = request.optInt("reversed", 0) == 1;

                        requestArrayData.addRequestData(i, txTimestamp, rxTimestamp, rtt, duplicated, reversed);
                    }
                }
            } else {
                throw new RuntimeException("Format non supporté : 'request_array' requis");
            }

        } catch (Exception e) {
            throw new RuntimeException("Erreur chargement " + fileName + ": " + e.getMessage());
        }
    }

    public RequestArrayData getRequestArrayData() { return requestArrayData; }
    public boolean hasData() { return requestArrayData.hasData(); }
}