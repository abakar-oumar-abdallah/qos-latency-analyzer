package com.qos.latency.analyzer.view;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import com.github.mikephil.charting.charts.ScatterChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LegendEntry;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.ScatterData;
import com.github.mikephil.charting.data.ScatterDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.qos.latency.analyzer.model.LatencyModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Vue graphique pour l'affichage des données request_array.
 *
 * Affiche les paquets réseau en nuage de points avec code couleur selon leur statut.
 *
 * @author Équipe QoS Gaming
 * @version 3.0
 */
public class ChartView extends ScatterChart implements OnChartValueSelectedListener {

    private boolean useTimestampMode = false;
    private final Map<Entry, LatencyModel.RequestData> entryToPacketMap = new HashMap<>();
    private final Map<String, ScatterDataSet> datasetMap = new HashMap<>();

    // Couleurs pour les statuts de paquets
    private static final int COLOR_RECEIVED = Color.parseColor("#4CAF50");
    private static final int COLOR_LOST = Color.parseColor("#F44336");
    private static final int COLOR_DUPLICATED = Color.parseColor("#FF9800");
    private static final int COLOR_REVERSED = Color.parseColor("#9C27B0");

    public ChartView(Context context) {
        super(context);
        initChart();
    }

    public ChartView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initChart();
    }

    /**
     * Initialise la configuration du graphique.
     */
    private void initChart() {
        getDescription().setText("RTT vs Temps - request_array");
        setOnChartValueSelectedListener(this);

        // Marges pour la légende
        setExtraTopOffset(20f);
        setExtraBottomOffset(80f);
        setExtraLeftOffset(20f);
        setExtraRightOffset(100f);

        setupAxes();
        setupLegend();
    }

    /**
     * Configure les axes X et Y.
     */
    private void setupAxes() {
        XAxis xAxis = getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return String.format(Locale.getDefault(), "%.2f s", value);
            }
        });

        YAxis leftAxis = getAxisLeft();
        leftAxis.setAxisMinimum(0f);
        leftAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return String.format(Locale.getDefault(), "%.0f ms", value);
            }
        });

        getAxisRight().setEnabled(false);
    }

    /**
     * Configure la légende avec position fixe.
     */
    private void setupLegend() {
        Legend legend = getLegend();
        legend.setEnabled(true);
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        legend.setOrientation(Legend.LegendOrientation.VERTICAL);
        legend.setDrawInside(true);
        legend.setTextSize(12f);
        legend.setTextColor(Color.parseColor("#424242"));
        legend.setFormSize(12f);
        legend.setXEntrySpace(8f);
        legend.setYEntrySpace(6f);
        legend.setFormToTextSpace(6f);
        legend.setXOffset(15f);
        legend.setYOffset(30f);
    }

    public void setTimestampMode(boolean enabled) {
        this.useTimestampMode = enabled;
    }

    /**
     * Ajoute un point représentant un paquet sur le graphique.
     */
    public void addPacketPoint(LatencyModel.RequestData packet) {
        if (!useTimestampMode) return;

        float xValue = getTimeInSeconds(packet);
        float yValue = getRttInMs(packet);

        ScatterDataSet dataSet = getOrCreateDataSet(packet.getStatus());
        Entry entry = new Entry(xValue, yValue);
        dataSet.addEntry(entry);

        entryToPacketMap.put(entry, packet);
        updateChart();
    }

    /**
     * Calcule le temps d'affichage en secondes.
     */
    private float getTimeInSeconds(LatencyModel.RequestData packet) {
        if (packet.getStatus() == LatencyModel.PacketStatus.LOST) {
            return (float) packet.getTxTimeRelative();
        } else {
            return (float) packet.getRxTimeRelative();
        }
    }

    /**
     * Calcule le RTT d'affichage en millisecondes.
     */
    private float getRttInMs(LatencyModel.RequestData packet) {
        if (packet.getStatus() == LatencyModel.PacketStatus.LOST) {
            return 0f;
        } else {
            return (float) packet.getRtt();
        }
    }

    /**
     * Récupère ou crée le dataset pour un statut.
     */
    private ScatterDataSet getOrCreateDataSet(LatencyModel.PacketStatus status) {
        String key = status.name();

        if (!datasetMap.containsKey(key)) {
            String label = getStatusLabel(status);
            int color = getStatusColor(status);

            ScatterDataSet dataSet = new ScatterDataSet(new ArrayList<>(), label);
            dataSet.setColor(color);
            dataSet.setScatterShape(ScatterChart.ScatterShape.CIRCLE);
            dataSet.setScatterShapeSize(12f);
            dataSet.setDrawValues(false);
            dataSet.setHighlightEnabled(true);

            datasetMap.put(key, dataSet);
        }

        return datasetMap.get(key);
    }

    private int getStatusColor(LatencyModel.PacketStatus status) {
        switch (status) {
            case RECEIVED: return COLOR_RECEIVED;
            case LOST: return COLOR_LOST;
            case DUPLICATED: return COLOR_DUPLICATED;
            case REVERSED: return COLOR_REVERSED;
            default: return COLOR_RECEIVED;
        }
    }

    private String getStatusLabel(LatencyModel.PacketStatus status) {
        switch (status) {
            case RECEIVED: return "Paquets reçus";
            case LOST: return "Paquets perdus";
            case DUPLICATED: return "Paquets dupliqués";
            case REVERSED: return "Paquets inversés";
            default: return "Autres";
        }
    }

    /**
     * Met à jour l'affichage avec les datasets et la légende.
     */
    private void updateChart() {
        if (datasetMap.isEmpty()) return;

        List<ScatterDataSet> orderedDatasets = new ArrayList<>();

        // Ordre d'affichage fixe pour une légende cohérente
        if (datasetMap.containsKey("RECEIVED")) {
            orderedDatasets.add(datasetMap.get("RECEIVED"));
        }
        if (datasetMap.containsKey("REVERSED")) {
            orderedDatasets.add(datasetMap.get("REVERSED"));
        }
        if (datasetMap.containsKey("DUPLICATED")) {
            orderedDatasets.add(datasetMap.get("DUPLICATED"));
        }
        if (datasetMap.containsKey("LOST")) {
            orderedDatasets.add(datasetMap.get("LOST"));
        }

        setData(new ScatterData(orderedDatasets.toArray(new ScatterDataSet[0])));
        updateLegend();
        notifyDataSetChanged();
        invalidate();
    }

    /**
     * Met à jour la légende dans l'ordre correct.
     */
    private void updateLegend() {
        List<LegendEntry> entries = new ArrayList<>();

        if (datasetMap.containsKey("RECEIVED")) {
            entries.add(new LegendEntry("Paquets reçus", Legend.LegendForm.CIRCLE, 12f, 2f, null, COLOR_RECEIVED));
        }
        if (datasetMap.containsKey("REVERSED")) {
            entries.add(new LegendEntry("Paquets reçus inversés", Legend.LegendForm.CIRCLE, 12f, 2f, null, COLOR_REVERSED));
        }
        if (datasetMap.containsKey("DUPLICATED")) {
            entries.add(new LegendEntry("Paquets reçus dupliqués", Legend.LegendForm.CIRCLE, 12f, 2f, null, COLOR_DUPLICATED));
        }
        if (datasetMap.containsKey("LOST")) {
            entries.add(new LegendEntry("Paquets perdus", Legend.LegendForm.CIRCLE, 12f, 2f, null, COLOR_LOST));
        }

        if (!entries.isEmpty()) {
            getLegend().setCustom(entries);
        }
    }

    @Override
    public void onValueSelected(Entry e, Highlight h) {
        LatencyModel.RequestData packet = entryToPacketMap.get(e);
        if (packet != null) {
            String info = String.format(Locale.getDefault(),
                    "Séq %d | %s | (%.2fs, %.1fms)",
                    packet.getSequenceNumber(),
                    getShortStatusText(packet.getStatus()),
                    e.getX(), e.getY()
            );
            getDescription().setText(info);
            invalidate();
        }
    }

    private String getShortStatusText(LatencyModel.PacketStatus status) {
        switch (status) {
            case RECEIVED: return "Reçu";
            case LOST: return "Perdu";
            case DUPLICATED: return "Dupliqué";
            case REVERSED: return "Inversé";
            default: return "Inconnu";
        }
    }

    @Override
    public void onNothingSelected() {
        getDescription().setText("RTT vs Temps - request_array");
        invalidate();
    }

    public void clearAllSeries() {
        datasetMap.clear();
        entryToPacketMap.clear();
        clear();
        invalidate();
    }
}